function sidebar() {


    // return your html component here
    //Make sure to give input search box id as ""
}
export default sidebar